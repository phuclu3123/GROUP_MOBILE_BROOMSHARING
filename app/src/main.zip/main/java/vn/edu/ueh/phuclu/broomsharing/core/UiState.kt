package vn.edu.ueh.phuclu.broomsharing.core

// State wrapper quản lý trạng thái hiển thị trên UI
sealed class UiState<out T> {
    object Loading : UiState<Nothing>()
    data class Success<out T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}