package vn.edu.ueh.phuclu.broomsharing.core

// Callback xử lý kết quả bất đồng bộ từ Firebase
interface ResultCallback<T> {
    fun onSuccess(data: T)
    fun onError(exception: Exception)
}